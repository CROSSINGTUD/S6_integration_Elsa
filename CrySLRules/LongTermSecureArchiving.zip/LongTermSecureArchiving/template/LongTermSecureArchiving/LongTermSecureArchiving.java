package de.cognicrypt.codegenerator.crysl.templates.LongTermSecureArchiving;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import de.cognicrypt.codegenerator.crysl.CrySLCodeGenerator;
import de.tu_darmstadt.crossing.composable_crypto.interfaces.LongTermStorage.DataOwner.RetrieveOperation.ELSAVerificationFailedException;

public class LongTermSecureArchiving {
	public de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSAClient createELSAClient(String evidenceServiceURL, String shareholderURLs, de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.EvidenceServiceAdapter esAdapter, de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ShareholderAdapter shAdapter) {
		System.out.println("BEGIN GENERATED CONSTRUCTION CODE");
		de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSA.Builder construction = null;
		System.out.println("END GENERATED CONSTRUCTION CODE");
		
		de.tu_darmstadt.crossing.composable_crypto.core.ComponentConfiguration configuration = new de.tu_darmstadt.crossing.composable_crypto.core.ComponentConfiguration()
				.prop("evidenceServiceURL", evidenceServiceURL)
				.prop("shareholderURLs", shareholderURLs)
				.prop("esAdapter", esAdapter)
				.prop("shAdapter", shAdapter);
		de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSA elsa = (de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSA) construction.build();
		
		de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSAClient client = null;
		
		client = de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSAClient.getInstance(elsa);
		
		return client;
	}
	
	public java.util.UUID store(de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSAClient client, String data) {
		java.util.UUID uuid = null;
		InputStream inputStream = new ByteArrayInputStream(data.getBytes(StandardCharsets.UTF_8));
		
		de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSAStoreOperation eLSAStoreOperation = null;
		
		eLSAStoreOperation = de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSAStoreOperation.getInstance(client);
		
		uuid = eLSAStoreOperation.addFile(inputStream);
		
		eLSAStoreOperation.store();
		
		return uuid;
	}
	
	public String retrieve(de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSAClient client, java.util.UUID uuid) throws ELSAVerificationFailedException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		
		de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSARetrieveOperation eLSARetrieveOperation = null;
		
		eLSARetrieveOperation = de.tu_darmstadt.crossing.composable_crypto.components.custom.long_term_storage.ELSARetrieveOperation.getInstance(client);
		
		eLSARetrieveOperation.retrieveAndVerify(uuid, outputStream);
		
		String result = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		return result;
	}
}
